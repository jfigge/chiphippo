# Handoff: Chip Hippo toolbar space optimization

## Overview
Chip Hippo (TTL Breadboard Designer) has a single top toolbar holding 12+ controls. It is already at capacity, and starting a simulation adds Stop / Pause / Step / speed to the same row, pushing the layout past its limit. This handoff contains three design options that solve the space problem in different ways, plus a recommendation to ship 1a first, then layer in 1c.

Current toolbar order (left → right): New, Open, Save, Bill Of Materials, Toggle parts list (left sidebar), Toggle wire placement mode, Toggle bus placement mode (with width count), Hide wires, Probe board, Fit to screen, Open the Analyzer, Toggle simulation (Run).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. `Toolbar Layout Options.dc.html` is a side-by-side comparison document (three annotated options, each rendered in an idle row and a simulating row), not a runnable toolbar component.

The task is to **recreate the chosen option inside Chip Hippo's existing codebase**, using its established patterns, component library, and styling approach. Do not port the HTML or the accompanying `support.js` runtime — `support.js` only exists to render the comparison document in a browser.

Three PNGs of the current app are included as the "before" reference: `current-state-idle.png`, `current-state-simulating.png`, `current-state-analyzer.png`.

## Fidelity
**High-fidelity.** Colors, type sizes, control heights, radii, gaps, and copy are all final and specified below. Recreate pixel-accurately, but substitute Chip Hippo's existing icon set and button primitives rather than the placeholder SVGs in the HTML (those are simplified stand-ins — the real app already has correct icons).

## The three options

### Option 1a — Grouped clusters + mode-swap transport (recommended first ship)
Purest regrouping; no new surfaces, no relocation of anything the user already knows.

**Structure, left → right:**
1. **Brand block** — 26×26 rounded logo tile (radius 6, bg `#3F6B4A`) + "Chip Hippo" 14px/600, `letter-spacing:-0.01em`. `white-space:nowrap; flex-shrink:0`.
2. **File split button** — a single 28px-tall control, radius 7, bg `#333`, border `1px solid #3F3F3F`. Primary half: document icon + label "New", 12.5px, padding `0 10px`. A `1px` divider (`#454545`), then a 20px-wide caret half (`▾`, 9px, `#9A9A9A`) opening a menu containing Open, Save, Save As…, Bill Of Materials. **New, Open, Save, and BOM shrink from 4 buttons to 1 control (~120px saved).** Keep ⌘N/⌘O/⌘S bound globally; show shortcuts in the menu.
3. Vertical divider — 1×20px, `#3A3A3A`.
4. **Canvas mode segmented group** — container `display:flex; gap:2px; background:#2F2F2F; border:1px solid #3A3A3A; border-radius:8px; padding:2px`. Children are 26px tall, radius 6. Active item: bg `#3D4C63`, text `#DCE6F6`. Inactive: text `#B5B5B5`, transparent bg (hover `#3A3A3A`). Contents: `Wire` (labeled), `Bus` (labeled + a mono `8` count chip: 10.5px, `#8F8F8F`, bg `#3A3A3A`, radius 4, padding `1px 4px`), then icon-only 28×26 buttons for Hide wires and Probe board. Because only one placement mode can be active at a time, this group must behave as a radio set — that is what justifies the segmented framing.
5. Vertical divider.
6. **View group** — same segmented container. Icon-only 28×26: Toggle parts list (shown active, bg `#3A3A3A`), Fit to screen.
7. `flex:1` spacer.
8. **Analyzer** button — 28px tall, radius 7, bg `#333`, border `#3F3F3F`, icon + "Analyzer" 12.5px, padding `0 11px`.
9. **Run** button — 28px, radius 7, bg `#2C3F30`, border `1px solid #46704F`, text `#8FDBA3` 12.5px/500, padding `0 13px`, play triangle 11px.
10. **Settings** gear — 24×24, `#8A8A8A`.

**Simulating state (the key idea):** editing tools are disabled during a sim anyway, so the whole canvas-mode group **collapses in place** into one non-interactive chip — bg `#2E2E2E`, `1px dashed #454545`, text `#8A8A8A` 12px, wire icon + copy "Editing tools locked", `white-space:nowrap`. The file split button dims to `opacity:.5`. The freed space (~180px) is taken by the **transport group** in the same segmented container style: `Stop` (bg `#40292B`, text `#F4A3A3` 12.5px/500, stop square icon), then icon-only 28×26 `Pause` and `Step`, then a speed control `×1 ▾` in mono 11.5px. After the transport, an elapsed-time readout: 6px green dot (`#8FDBA3`) + mono 11.5px `2.481 ms`, `white-space:nowrap; flex-shrink:0`. Analyzer, gear, and brand block stay put. **Nothing reflows — the row height and the position of Analyzer/gear are identical in both states.**

### Option 1b — Vertical tool rail on the canvas
Canvas tools leave the top bar entirely and become a floating vertical rail on the left edge of the canvas, where the pointer already is. The top bar then holds only document + simulation concerns and can never fill up again; the rail grows into unlimited vertical space, so this is the option that scales if tools are added later.

- **Top bar:** brand block + filename (`Analyzer-demo.chiphippo`, 12px `#7D7D7D`) · divider · one segmented group of four icon-only 28×26 buttons (New, Open, Save, BOM) · `flex:1` · Analyzer · Run · gear. Simulating: the file group dims to `opacity:.45` and the transport group (Stop / Pause / Step / ×1 ▾) appears where Run was, to the right of Analyzer.
- **Rail:** absolutely positioned `left:14px; top:14px` over the canvas. Container: `background:#282828; border:1px solid #3A3A3A; border-radius:10px; padding:4px; display:flex; flex-direction:column; gap:4px; box-shadow:0 6px 18px rgba(0,0,0,.45)`. Buttons are 34×32, radius 7; active uses bg `#3D4C63` with `#DCE6F6` icon. Order with `1px #3A3A3A` separators (inset `margin:2px 5px`): **Wire, Bus** (Bus carries a 9px mono `8` badge bottom-right) — sep — **Hide wires, Probe board** — sep — **Fit to screen, Toggle parts list**.
- **Tooltips:** rail buttons show a tooltip to the right on hover — bg `#111`, border `#3A3A3A`, radius 6, padding `5px 9px`, 11.5px `#D6D6D6`, with the shortcut in mono `#8A8A8A` (e.g. "Wire mode  W").
- Zoom readout stays bottom-right of the canvas.

### Option 1c — Simulation as a floating HUD
The top bar never changes shape. Starting a sim spawns a floating transport pill over the canvas; the Run button in the toolbar simply becomes Stop in place (bg `#40292B`, border `#6B4348`, text `#F4A3A3`).

- **Pill:** absolutely positioned, horizontally centered, `bottom:18px` of the canvas viewport. `background:rgba(32,32,32,.94); border:1px solid #43363A; border-radius:999px; padding:6px 10px; display:flex; align-items:center; gap:8px; box-shadow:0 10px 30px rgba(0,0,0,.55)`. Contents: `Stop` (28px tall, radius 999, bg `#40292B`, `#F4A3A3` 12.5px/500, padding `0 12px`) · 30×28 pill `Pause` · 30×28 pill `Step` · 1×18px divider `#3F3F3F` · `×1 ▾` mono 11.5px, padding `0 9px` · elapsed readout (green dot + mono `2.481 ms`, `#8FDBA3`).
- **Docking:** when the Logic analyzer drawer opens from the bottom, the pill must stay above the drawer — anchor it to the bottom of the *canvas viewport*, not the window, so the drawer opening pushes it up rather than covering it.
- Top bar in this option also uses 1a's File split button and segmented canvas-mode group; the two options compose.
- Trade-off to accept: the pill occludes a small strip of canvas. Consider fading it to `opacity:.35` after ~3s of no pointer movement, restoring on hover.

## Interactions & Behavior
- **Mode group is exclusive.** Wire, Bus, Hide wires, Probe board — activating one deactivates the others. Escape returns to select mode.
- **Every icon-only button needs a tooltip with its keyboard shortcut.** This is a requirement of all three options; collapsing labels is only acceptable with discoverable tooltips.
- **Disabled ≠ removed.** While a sim runs, editing controls dim (1b/1c) or collapse into the single locked chip (1a). Never unmount them — the row must not reflow, and Analyzer/gear must not move.
- **File menu (1a/1c):** click the caret half opens the menu; click the primary half performs New directly. Menu items: Open, Save, Save As…, Bill Of Materials, each with its shortcut right-aligned.
- **Speed control** `×1 ▾` opens a small menu (e.g. ×0.25, ×0.5, ×1, ×2, ×4, Max).
- **Elapsed readout** updates on the sim tick; the dot pulses only while running, is solid while paused.
- **Transitions:** state swaps (1a's collapse, 1c's pill in/out) should be short — 120–150ms, `ease-out`; opacity + 4px translate for the pill, opacity + width for the collapsing group. No layout animation on the toolbar row itself.
- **Responsive:** below the width where the mode group's labels fit, drop "Wire"/"Bus" text to icon-only before dropping anything else. Below that, move Fit to screen and Toggle parts list into an overflow `⋯` menu. Never wrap the toolbar to two rows.

## State Management
- `simState: 'idle' | 'running' | 'paused'` — drives Run↔Stop, transport visibility, and the disabled/collapsed treatment of editing controls.
- `activeCanvasMode: 'select' | 'wire' | 'bus' | 'hideWires' | 'probe'` — single value backing the exclusive segmented group.
- `busWidth: number` — the `8` badge.
- `simSpeed: number` — the `×1` control.
- `elapsedMs: number` — the readout; throttle UI updates to ~10 Hz so the sim loop isn't taxed.
- `partsListOpen: boolean`, `analyzerOpen: boolean` — panel toggles; `analyzerOpen` also affects the 1c pill's anchor.
- `fileMenuOpen`, `speedMenuOpen`, `overflowMenuOpen: boolean`.

## Design Tokens
Colors
- Toolbar bg `#282828` · canvas `#1C1C1C` (dot grid `#2E2E2E`, 11px pitch) · sidebar/drawer `#202020` · popover `#111`
- Borders `#333` (bar edge), `#3A3A3A` (control group), `#3F3F3F` (button), `#454545` (divider inside a split button), `#2E2E2E` (panel seam)
- Control surfaces: `#333` (button), `#2F2F2F` (group track), `#3A3A3A` (active icon button), `#2E2E2E` (disabled)
- Text: `#E8E8E8` primary · `#D6D6D6` control label · `#C9C9C9`/`#B5B5B5` icon · `#9A9A9A` secondary · `#8A8A8A` tertiary · `#7D7D7D` muted
- Active mode: bg `#3D4C63`, fg `#DCE6F6`
- Run/success: bg `#2C3F30`, border `#46704F`, fg `#8FDBA3`
- Stop/danger: bg `#40292B`, border `#6B4348`, fg `#F4A3A3`

Metrics
- Control height 28px; segmented child height 26px; icon-only child 28×26; rail button 34×32
- Radii: 6 (segmented child, small icon tile), 7 (standalone button, group in 1a), 8 (segmented container), 10 (floating rail), 999 (HUD pill and its children)
- Gaps: 2px inside a segmented group, 6–8px between related controls, 12px between clusters; toolbar padding `10px 14px`
- Dividers: 1×20px `#3A3A3A` between clusters
- Shadows: rail `0 6px 18px rgba(0,0,0,.45)`; HUD pill `0 10px 30px rgba(0,0,0,.55)`; tooltip `0 4px 12px rgba(0,0,0,.5)`

Typography
- UI: system stack (`-apple-system, 'Helvetica Neue', Helvetica, sans-serif`). Brand 14px/600 `-0.01em`; control labels 12.5px/400; secondary 12px; badges/section labels 11–11.5px with `0.08em` tracking on all-caps.
- Numeric: mono stack (`ui-monospace, 'SF Mono', Menlo, monospace`) for the bus width badge (10.5px), speed, zoom %, and elapsed time (11.5px).

## Assets
No new assets. All icons in the prototype are simplified placeholder SVGs — **use Chip Hippo's existing icon set**. Icons needed: document/new, folder/open, floppy/save, clipboard/BOM, panel-left, wire, bus, wire-hidden, probe/crosshair, fit-to-screen, waveform/analyzer, play, stop, pause, step-forward, gear, chevron-down.

## Files
- `Toolbar Layout Options.dc.html` — the three annotated options, idle and simulating rows for each. Open directly in a browser.
- `support.js` — runtime needed only to render the file above. Not part of the design.
- `option-1a.png`, `option-1b.png`, `option-1c.png` — screenshots of each option. These are captured at a narrow viewport and are **cropped on the right**; open the HTML file for the full-width truth.
- `current-state-idle.png`, `current-state-simulating.png`, `current-state-analyzer.png` — the app today, for before/after comparison.

## Suggested implementation order
1. Option **1a** — regrouping only, lowest risk, immediately relieves the pressure.
2. Option **1c**'s floating transport — after that, simulation never costs toolbar width again.
3. Option **1b** — hold in reserve for when the tool count outgrows a single row.
